function start() {
        cm.dispose();
}