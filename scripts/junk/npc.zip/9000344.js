


/*

�Ϳ��÷��� (wow_plus)


*/
var itemsz0 = new Array(new Array(10, 1004168, 1), new Array(10, 1004156, 1), new Array(10, 1004169, 1), new Array(10, 1004170, 1), new Array(10, 1000077, 1), new Array(10, 1003043, 1), new Array(10, 1003048, 1), new Array(10, 1003009, 1), new Array(10, 1002720, 1), new Array(10, 1003862, 1), new Array(10, 1004120, 1), new Array(10, 1004156, 1), new Array(10, 1004414, 1), new Array(10, 1000079, 1), new Array(9000, 1001100, 1), new Array(9000, 1003789, 1), new Array(9000, 1002885, 1), new Array(9000, 1003131, 1), new Array(9000, 1003132, 1), new Array(9000, 1003133, 1), new Array(9000, 1004212, 1), new Array(9000, 1004385, 1), new Array(9000, 1003207, 1), new Array(9000, 1004279, 1), new Array(9000, 1003149, 1), new Array(9000, 1004268, 1), new Array(9000, 1001097, 1), new Array(9000, 1000074, 1), new Array(9000, 1004158, 1), new Array(9000, 1004181, 1), new Array(9000, 1003910, 1), new Array(9000, 1004213, 1), new Array(9000, 1003859, 1), new Array(9000, 1004197, 1), new Array(9000, 1003902, 1), new Array(100, 1003271, 1), new Array(9000, 1003900, 1), new Array(9000, 1003548, 1), new Array(9000, 1003549, 1), new Array(9000, 1000077, 1), new Array(9000, 1001099, 1), new Array(9000, 1004467, 1), new Array(9000, 1004468, 1), new Array(9000, 1004469, 1), new Array(9000, 1004470, 1), new Array(9000, 1004460, 1), new Array(9000, 1004459, 1), new Array(9000, 1004458, 1), new Array(9000, 1004454, 1), new Array(9000, 1004453, 1), new Array(9000, 1004450, 1), new Array(9000, 1004447, 1));
var itemsz1 = new Array(new Array(9000, 1050351, 1), new Array(9000, 1051420, 1), new Array(9000, 1052845, 1), new Array(9000, 1050341, 1), new Array(9000, 1052626, 1), new Array(9000, 1050322, 1), new Array(9000, 1051392, 1), new Array(9000, 1051405, 1), new Array(9000, 1050319, 1), new Array(9000, 1051390, 1), new Array(100, 1050337, 1), new Array(9000, 1051406, 1), new Array(9000, 1051387, 1), new Array(9000, 1050234, 1), new Array(9000, 1051284, 1), new Array(9000, 1050343, 1), new Array(9000, 1051411, 1), new Array(9000, 1050340, 1), new Array(9000, 1051409, 1), new Array(9000, 1052909, 1), new Array(9000, 1052912, 1));
var itemsz2 = new Array(new Array(9000, 1042238, 1), new Array(9000, 1042341, 1), new Array(9000, 1042290, 1), new Array(9000, 1042315, 1), new Array(9000, 1042275, 1), new Array(9000, 1042313, 1), new Array(9000, 1042271, 1), new Array(9000, 1042235, 1), new Array(9000, 1042269, 1));
var itemsz3 = new Array(new Array(9000, 1062185, 1), new Array(9000, 1062183, 1), new Array(9000, 1062216, 1), new Array(9000, 1062207, 1), new Array(9000, 1062151, 1));
var itemsz4 = new Array(new Array(9000, 1102503, 1), new Array(9000, 1102789, 1), new Array(9000, 1100004, 1), new Array(9000, 1101000, 1), new Array(9000, 1102675, 1), new Array(9000, 1102759, 1), new Array(9000, 1102748, 1), new Array(9000, 1102747, 1), new Array(9000, 1102674, 1), new Array(9000, 1102688, 1), new Array(9000, 1102669, 1), new Array(9000, 1102204, 1), new Array(9000, 1102510, 1), new Array(9000, 1102725, 1), new Array(9000, 1102707, 1), new Array(9000, 1102708, 1), new Array(9000, 1102420, 1), new Array(9000, 1102815, 1), new Array(9000, 1102816, 1), new Array(9000, 1102812, 1), new Array(9000, 1102811, 1), new Array(9000, 1102809, 1));
var itemsz5 = new Array(new Array(9000, 1012489, 1), new Array(9000, 1012485, 1), new Array(9000, 1012427, 1), new Array(9000, 1012428, 1), new Array(9000, 1012429, 1), new Array(9000, 1012430, 1), new Array(9000, 1012431, 1), new Array(9000, 1012432, 1), new Array(9000, 1012433, 1), new Array(9000, 1012434, 1), new Array(9000, 1012435, 1), new Array(9000, 1012436, 1), new Array(9000, 1012468, 1));
var itemsz6 = new Array(new Array(9000, 1022196, 1), new Array(9000, 1022177, 1), new Array(9000, 1022188, 1), new Array(9000, 1022229, 1));
var itemsz7 = new Array(new Array(9000, 1702553, 1), new Array(9000, 1702502, 1), new Array(9000, 1702562, 1), new Array(9000, 1702525, 1), new Array(9000, 1702365, 1), new Array(9000, 1702480, 1), new Array(9000, 1702550, 1), new Array(9000, 1702464, 1), new Array(9000, 1702485, 1), new Array(9000, 1702503, 1), new Array(9000, 1702512, 1), new Array(9000, 1702528, 1), new Array(9000, 1702505, 1), new Array(9000, 1702541, 1), new Array(9000, 1702535, 1), new Array(9000, 1702487, 1), new Array(9000, 1702521, 1), new Array(9000, 1702362, 1), new Array(9000, 1702329, 1), new Array(9000, 1702497, 1), new Array(9000, 1702530, 1), new Array(9000, 1702529, 1), new Array(9000, 1702574, 1), new Array(9000, 1702575, 1), new Array(9000, 1702576, 1), new Array(9000, 1702584, 1), new Array(9000, 1702571, 1), new Array(9000, 1702570, 1), new Array(9000, 1702565, 1));
var itemsz8 = new Array(new Array(9000, 1112182, 1), new Array(9000, 1112180, 1), new Array(9000, 1112178, 1), new Array(9000, 1112170, 1), new Array(9000, 1112295, 1), new Array(9000, 1112293, 1), new Array(9000, 1112290, 1), new Array(9000, 1112282, 1));

var itemCategorys = new Array("#b����", "�ѹ���", "����", "����", "\r\n�� ����", "�����", "�����", "����", "����");


var status = -1;
var menuSelect = -1;
var select = -1;


function start() {
    status = -1;
    action (1, 0, 0);
}

function action(mode, type, selection) {
    if (mode == -1 || mode == 0) {
        cm.dispose();
        return;
    }
    if (mode == 1) {
        status++;
    }
    
    if (status == 0) {
	var leaf = cm.itemQuantity(4310067);
        var trade = "#e�ֽž�����#n�� ��ȯ�ص帮�ڽ��ϴ�. �� �����۵��� ��¥ �����۵��Դϴ�. \r\n\r\n������ ���� #e:#n #i4310067# #r#z4310067# 0 ��#k \r\n\r\n";
        for (var i = 0; i < itemCategorys.length; i++) {
            trade += "#L"+i+"#"+itemCategorys[i]+"#l";
        }
        cm.sendSimple(trade);
    } else if (status == 1) {
        menuSelect = selection;
        var trade = "���ϴ� �������� ��󺸼���.\r\n\r\n";
        var itemsArray = getArray(selection);
        for (var i = 0;i < itemsArray.length; i++) {
            trade += "#L"+i+"##i"+itemsArray[i][1]+"# #z"+itemsArray[i][1]+"##b < �Ŀ����� 0�� >#l#k\r\n";
        }
        cm.sendSimple(trade);
    } else if (status == 2) {
        select = selection;
        var itemsArray = getArray(menuSelect);
        cm.sendYesNo("#b#i"+itemsArray[select][1]+"# #z"+itemsArray[select][1]+"##k ���� �̾����� �����Ͻðڽ��ϱ�?");
    } else if (status == 3) {
        var itemsArray = getArray(menuSelect);
        if (cm.haveItem(4310067, 0) && cm.canHold(itemsArray[select][1])) {
            cm.gainItem(4310067, -0);
            cm.gainSponserItem(itemsArray[select][1],'[�޸տ¶���]',0,0,0);
            cm.sendOk("#i4310067# 10���� #i"+itemsArray[select][1]+"#�� ��ȯ�ϼ˽��ϴ�.");
            cm.dispose();
        } else {
            cm.sendOk("�κ��丮�� ���� á�ų� #i4310067# �� �����մϴ�.");
            cm.dispose();
            return;
        }
    }
}

function getArray(sel) {
if (sel==0)return itemsz0;
if (sel==1)return itemsz1;
if (sel==2)return itemsz2;
if (sel==3)return itemsz3;
if (sel==4)return itemsz4;
if (sel==5)return itemsz5;
if (sel==6)return itemsz6;
if (sel==7)return itemsz7;
if (sel==8)return itemsz8;
}