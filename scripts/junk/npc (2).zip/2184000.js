importPackage(java.lang);
var status = 0;
var map = 262000000;

function start() {
    status = -1;
    action(1, 0, 0);
}

function action(mode, type, selection) {
    if (status <= 0 && mode == 0) {
        cm.dispose();
        return;
    }
    if (mode == 1) status++;
    else status--;
    if (status == 0) {
		var exit = cm.getPlayer().getClient().getChannelServer().getMapFactory().getMap(262000000);
		var eim = cm.getPlayer().getEventInstance();
		if (eim == null) {
			cm.getPlayer().changeMap(exit, exit.getPortal(0));
			return true;
		}
		if (eim.getProperty("CurrentStage").equals("4")) {
			eim.unregisterPlayer(cm.getPlayer());
			cm.getPlayer().changeMap(exit, exit.getPortal(0));
			cm.dispose();
			return true;
		} else {
			cm.sendYesNo("�׸� �ΰ� �����ðڽ��ϱ�?");
		}
    } else if (status == 1) {
		var eim = cm.getPlayer().getEventInstance();
		eim.stopEventTimer();
		if (cm.getPlayer().getParty() != null) {
			if (!cm.isLeader()) {
				eim.leftParty(cm.getPlayer());
			} else {
				eim.disbandParty();
			}
		} else {
			eim.unregisterPlayer(cm.getPlayer());
			cm.warp(262000000, 0);
		}
		cm.dispose();
    }
}