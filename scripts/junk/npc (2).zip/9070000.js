var status = -1;

function action(mode, type, selection) {
	cm.sendPVPWindow();
	cm.dispose();
}