function start () {
cm.teachSkill(80001245,1,1);
cm.dispose();
}