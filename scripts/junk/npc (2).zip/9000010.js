function start() {
  cm.warp(1000000);
  cm.dispose();
}