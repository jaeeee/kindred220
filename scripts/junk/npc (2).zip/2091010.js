function start() {
    cm.MulungList();
    cm.dispose();
}

